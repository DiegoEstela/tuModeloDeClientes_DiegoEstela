
from setuptools import setup, find_packages

setup(
    name='modelo-de-clientes',
    version='1.0.0',
    packages=find_packages(),
    install_requires=[],
    author='Diego Estela',
    author_email='die.estela@email.com',
    description='Modelamiento de Clientes en una página de compras',
)
